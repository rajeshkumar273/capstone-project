package com.ecommerce.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.ecommerce.application.modal.Admin;
import com.ecommerce.application.repo.AdminRepo;


public class AdminController {
	@Autowired
	private AdminRepo adminRepo;
	
	 @PostMapping("/adminRepo")
	    public Admin createAdmin(@RequestBody Admin reg) {
	        return adminRepo.save(reg);
	    }
	 @GetMapping("/adminlogin")
	    public List < Admin > checkUser() {
	        return adminRepo.findAll();
	 }
}

