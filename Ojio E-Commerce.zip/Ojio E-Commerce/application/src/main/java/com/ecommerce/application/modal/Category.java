package com.ecommerce.application.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Category")
public class Category {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "Category_id")
	    private int Category_id;
	 
	    @Column(name = "category_name",length=15)
	    private String category_name;
	    
	
	    @Column(name = "category_des",length=100)
	    private String category_des;
	    
	    
	    
		public Category() {
			super();
			// TODO Auto-generated constructor stub
		}
		public String getcategory_name() {
			return category_name ;
		}
		public void setcategory_name(String category_name) {
			this.category_name = category_name;
		}
		public String getcategory_des() {
			return category_des;
		}
		public void setV(String category_des) {
			this.category_des = category_des;
		}
		
		
		public long getCategory_id() {
			return Category_id;
		}
		
	    

}